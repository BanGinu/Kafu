﻿namespace Kafu.Model.Helper
{
    public static class GenerateHelper
    {

   
   
    }
}
