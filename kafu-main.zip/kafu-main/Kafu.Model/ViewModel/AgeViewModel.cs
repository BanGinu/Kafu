﻿namespace Kafu.Model.ViewModel
{
    class AgeViewModel
    {
    }
}
