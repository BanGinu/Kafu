﻿namespace Kafu.Model.ViewModel
{
    public class EmployeeItem
    {
        public string Text { get; set; }
        public string Value { get; set; }
        public bool Selected { get; set; }
        public string Description { get; set; }
        public string ImageSrc { get; set; }
        public string Email { get; set; }

    }
}
