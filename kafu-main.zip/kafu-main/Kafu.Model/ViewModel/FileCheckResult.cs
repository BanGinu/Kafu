﻿namespace Kafu.Model.ViewModel
{
    public class FileCheckResult
    {
        public byte[] Data { get; set; }
        public bool IsValidFile { get; set; }
    }
}
