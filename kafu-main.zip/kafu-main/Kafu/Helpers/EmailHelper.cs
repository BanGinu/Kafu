﻿using System.Net.Mail;
using Kafu.Model.ViewModel;


namespace Kafu.WebUI.Helpers
{
    public class EmailHelper
    {
        public static async Task SendEmail(EmailConfig emailSettings, string mailBody, string toEmail, string subject, List<string> ccEmails = null)
        {

            MailMessage message = new MailMessage();
            message.To.Add(new MailAddress(toEmail));
            message.Subject = subject;
            message.Body = mailBody;
            message.From = new MailAddress(emailSettings.FromEmail, "كفو");
            message.Priority = MailPriority.Normal;
            message.IsBodyHtml = true;

            if (ccEmails?.Any() == true)
            {
                foreach (var item in ccEmails)
                {
                    MailAddress mail = new MailAddress(item);
                    message.CC.Add(mail);
                }
            }


            try
            {
               
                SmtpClient smtpClient = new SmtpClient
                {
                    Host = emailSettings.Host,
                    Port = emailSettings.Port,
                    EnableSsl = emailSettings.EnableSsl,
                    Credentials = new System.Net.NetworkCredential(emailSettings.Username, emailSettings.Password)
                };

                smtpClient.SendAsync(message, null);
              
            }
            catch (Exception ex)
            {
                //Handle exception
            }

        }

        public static async Task SendEmailList(EmailConfig emailSettings, string mailBody, List<string> toEmail, string subject)
        {
            MailMessage message = new MailMessage
            {
                Subject = subject,
                Body = mailBody,
                From = new MailAddress(emailSettings.FromEmail, "كفو"),
                Priority = MailPriority.High,
                IsBodyHtml = true
            };

            if (toEmail?.Any() == true)
            {
                foreach (var item in toEmail)
                {
                    MailAddress mail = new MailAddress(item);
                    message.To.Add(mail);
                }
                try
                {

                    SmtpClient smtpClient = new SmtpClient
                    {
                        Host = emailSettings.Host,
                        Port = emailSettings.Port,
                        EnableSsl = emailSettings.EnableSsl,
                        Credentials = new System.Net.NetworkCredential(emailSettings.Username, emailSettings.Password)
                    };
                    smtpClient.SendAsync(message, null);

                }
                catch (Exception ex)
                {

                }
            }
        }


    }
}
