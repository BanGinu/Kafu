﻿using Microsoft.AspNetCore.Mvc;
using Kafu.Model.ViewModel;
using Kafu.Model;
using Kafu.Model.Services;
using Kafu.Model.Entities;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.Extensions.Options;
using Kafu.WebUI.Helpers;
using Kafu.Model.Resource;
using Kafu.Model.Helper;
using System.Text.RegularExpressions;

namespace Kafu.WebUI.Controllers
{
    public class HomeController : BaseController
    {
        private readonly Kafu_SystemContext _context;
        private IWebHostEnvironment _environment;
        protected EmailConfig _emailSettings;
        IDataProtector _protector;
        private readonly IHttpContextAccessor _httpContextAccessor;
        protected readonly string _domain; 

        public HomeController(IKafuServices kafuServices, IHttpContextAccessor httpContextAccessor, IOptions<EmailConfig> emailSettings, ILogger<HomeController> logger, LocService localizationHelper,
            IWebHostEnvironment environment, Kafu_SystemContext context, IDataProtectionProvider provider) :
            base(kafuServices, logger, localizationHelper)
        {
            _context = context;
            _environment = environment;
            _protector = provider.CreateProtector(GetType().FullName);
            _emailSettings = emailSettings.Value;
            _httpContextAccessor = httpContextAccessor;
            _domain = ConfigurationHelper.GetValue<string>("Domain");

        }
        private async Task<bool> LoadData()
        {
            var from = User.Identity.Name.Split('\\').ElementAt(1);
            Employee employee_From = await KafuServices.GetEmployee(Email: from + "@" + _domain);
            ViewBag.Name = employee_From.AR_F_NAME + " " + employee_From.AR_L_NAME;

            ViewBag.KafuGiven = 5 - KafuServices.KafuGivenCountInMonths(employee_From.EmployeeNumber, DateTime.Now);
            ViewBag.KafuEarned = KafuServices.GetKafuCount(employee_From.EmployeeNumber);
            return true;
        }

        [HttpGet("{id}")]
        [HttpGet("")]
        public async Task<IActionResult> Index(string id = null)
        {
            GiveKafuViewModel model = new GiveKafuViewModel();

            var CurrentUser = _httpContextAccessor.HttpContext.User.Identity.Name.Split('\\').ElementAt(1).Trim();
            Employee CurrentUser_employee = await KafuServices.GetEmployee(Email: (CurrentUser + "@" + _domain).Trim());

            // Get all kafu records from DB using employee number of the current user:
            var ReciervedKafuList = KafuServices.GetReciervedKafu(CurrentUser_employee.EmployeeNumber);
            // fill creator name for each one in ReciervedKafuList:
            model.ReciervedKafu = ReciervedKafuList;
            var SentKafuList = KafuServices.GetSentKafu(CurrentUser_employee.EmployeeNumber);
            model.SentKafu = SentKafuList;

            await LoadData();

            if (id != null)
            {

                Employee employee = await KafuServices.GetEmployee(Email: id + "@" + _domain);
                if (employee == null)
                {
                    return RedirectToAction("Index", new { id = "_" });
                }
                else
                {
                    // id
                    ViewBag.To = KafuServices.GetEmployeeSelectListItems().Where(x => x.Value == employee.EmployeeNumber);

                    model.To = employee.EmployeeNumber;
                }

                return View(model);
            }
            else
            {
                // To prevent it from choosing the first employee 
                ViewBag.To = KafuServices.GetEmployeeSelectListItems().Where(x => x.Value == "");
                model.To = "";

                return View(model);
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> GiveKafu(GiveKafuViewModel model)
        {
            try
            {
                var from = User.Identity.Name.Split('\\').ElementAt(1);

                // get employees info
                string EmployeeToBlackList = @"[^\d]+";
                if (Regex.Match(model.To?.Trim(), EmployeeToBlackList).Success)
                {
                    TempData["Error"] = "لا يوجد بيانات لمستقبل الكفو ";
                    return RedirectToAction("Index");
                }
                Employee employee_To = KafuServices.GetEmployeeByNumber(model.To?.Trim());
                Employee employee_From = await KafuServices.GetEmployee(Email: from + "@" + _domain);
                if (employee_To == null || employee_From == null)
                {
                    TempData["Error"] = "لا يوجد بيانات لمستقبل الكفو ";
                    return RedirectToAction("Index");
                }
                // User doesn't send Kafu to himself
                if (employee_To == employee_From)
                {
                    TempData["Warning"] = "أنت كفو ما يحتاج تشكر نفسك";
                    return RedirectToAction("Index");
                }
                // User doesn't send more than one Kafu within a week to the same person 
                var NumberOfDays = KafuServices.GetNumberOfDayssinceLastKafuForSelectedEmployee(employee_To.EmployeeNumber, employee_From.EmployeeNumber);
                if (NumberOfDays == 0)
                {
                    TempData["Warning"] = "اليوم ارسلت لهالكفو إنه كفو، انتظر اسبوع زيادة";
                    return RedirectToAction("Index");
                }
                if (NumberOfDays != -1 && NumberOfDays <= 7)
                {
                    TempData["Warning"] = "ما مر اسبوع من ارسلت له كفو ";
                    return RedirectToAction("Index");
                }

                // MUST select a reason
                if (model.Reasons == null || model.Reasons.Count == 0)
                {
                    TempData["Warning"] = "لازم تختار سبب من الاسباب";
                    return RedirectToAction("Index");
                }
                else
                {
                    // Limit is 5 Kafus in a week
                    if (KafuServices.KafuGivenCountInMonths(employee_From.EmployeeNumber, DateTime.Now) >= 5)
                    {
                        TempData["Info"] = "خلص رصيدك في هالشهر انتظر الشهر الجاي";
                        return RedirectToAction("Index");
                    }
                }
                ReasonLookup reason = KafuServices.GetReasonById(model.Reasons.First());

                // Fill kafu record with needed data
                var kafu = new KafuRecord();
                kafu.CreatedOn = DateTime.Now;

                if (model.Comment != null)
                {
                    // Only allow arabic and engilsh characters, digits,
                    // and some speacial charachters that usually used in messages
                    var CommentBlacklist = @"[^a-zA-Z\u0621-\u064A\u0660-\u06690-9\s\n\t,.?!:;()'\-_،؟!؛‘]";
                    if (Regex.Match(model.Comment, CommentBlacklist).Success)
                    {
                        TempData["Warning"] = "لا يسمح بالحروف الخاصة بالرسالة";
                        return RedirectToAction("Index");
                    }
                    if (model.Comment.Length > 200)
                    {
                        TempData["Warning"] = "الرسالة ما تتعدى ٢٠٠ حرف ";
                        return RedirectToAction("Index");
                    }

                    kafu.Comment = model.Comment;
                }
                else
                {
                    kafu.Comment = " ";

                }
                kafu.CreatorId = employee_From.EmployeeNumber;
                kafu.Creator_name = employee_From.ArFullName;
                kafu.RecipientId = employee_To.EmployeeNumber;
                kafu.Recipient_name = employee_To.ArFullName;
                kafu.ReasonId = model.Reasons.First();
                string imgUrl;
                string imgAlt;
                // Put kafu logo link in imgUrl
                imgUrl = "";
                imgAlt = "for being Kafu";
                if (model.isMangerCC)
                {
                    kafu.isMangerCC = "true";
                }
                else
                {
                    kafu.isMangerCC = "false";
                }


                var sent = KafuServices.InsertKafuRecord(kafu);

                // Send email 
                if (!string.IsNullOrEmpty(sent.ToString()))
                {

                    var recipient_email = employee_To.Email;
                    var manger = KafuServices.GetMangerEmployee(employee_To.EmployeeNumber);

                    if (model.isMangerCC && manger != null)
                    {
                        // send email to recipient and his/her manger
                        var mangerEmail = manger.Email;

                        string ccsubject = "أنت كفو..!";
                        string ccbody = _localizationHelper.GetLocalizedHtmlString("Body");
                        ccbody = ccbody.Replace("{position}", employee_From.ArPosition);
                        ccbody = ccbody.Replace("{From}", employee_From.AR_F_NAME + " " + employee_From.AR_L_NAME);
                        ccbody = ccbody.Replace("{KafuReason}", reason.ArName);
                        ccbody = ccbody.Replace("{KafuImgSource}", imgUrl);
                        ccbody = ccbody.Replace("{KafuCount}", KafuServices.GetKafuCount(employee_To.EmployeeNumber).ToString());
                        ccbody = ccbody.Replace("{receipentName}", employee_To.AR_F_NAME + " " + employee_To.AR_L_NAME);
                        ccbody = ccbody.Replace("{message}", model.Comment);
                        ccbody = ccbody.Replace("{imgAlternative}", imgAlt);

                        await EmailHelper.SendEmail(_emailSettings, ccbody, recipient_email, ccsubject);

                        string subject = "عضو في فريقك كفو..!";

                        string body = _localizationHelper.GetLocalizedHtmlString("MangerBody");
                        body = body.Replace("{MangerName}", manger.AR_F_NAME);
                        body = body.Replace("{position}", employee_From.ArPosition);
                        body = body.Replace("{From}", employee_From.AR_F_NAME + " " + employee_From.AR_L_NAME);
                        body = body.Replace("{KafuReason}", reason.ArName);
                        body = body.Replace("{KafuImgSource}", imgUrl);
                        body = body.Replace("{receipentName}", employee_To.AR_F_NAME + " " + employee_To.AR_L_NAME);
                        body = body.Replace("{message}", model.Comment);
                        body = body.Replace("{imgAlternative}", imgAlt);

                        await EmailHelper.SendEmail(_emailSettings, body, mangerEmail, subject);
                    }
                    else
                    {
                        // send email to recipient

                        string subject = "أنت كفو ..!";
                        string body = _localizationHelper.GetLocalizedHtmlString("Body");
                        body = body.Replace("{position}", employee_From.ArPosition);
                        body = body.Replace("{From}", employee_From.AR_F_NAME + " " + employee_From.AR_L_NAME);
                        body = body.Replace("{KafuReason}", reason.ArName);
                        body = body.Replace("{KafuImgSource}", imgUrl);
                        body = body.Replace("{KafuCount}", KafuServices.GetKafuCount(employee_To.EmployeeNumber).ToString());
                        body = body.Replace("{receipentName}", employee_To.AR_F_NAME + " " + employee_To.AR_L_NAME);
                        body = body.Replace("{message}", model.Comment);
                        body = body.Replace("{imgAlternative}", imgAlt);

                        await EmailHelper.SendEmail(_emailSettings, body, recipient_email, subject);
                    }
                }

            }
            catch (Exception e)
            {

                TempData["Error"] = "حدث خطأ";
                return RedirectToAction("Index", "Home");
            }


            TempData["Alert"] = "تم إرسال الكفو بنجاح";
            return RedirectToAction("Index", "Home");
        }


        [HttpPost]
        public async Task<JsonResult> GetEmployeeList(string term)
        {
            if (string.IsNullOrEmpty(term))
                return Json(new List<EmployeeItem>());
            var employee = await KafuServices.GetEmployeesItem(term);
            return Json(employee);
        }




        //------------------- Helper Methods:

        private List<KafuRecord> FillEmpName(List<KafuRecord> list)
        {
            if (list != null)
            {
                foreach (var item in list)
                {
                    var user = KafuServices.GetEmployeeByNumber(item.CreatorId);
                    if (user != null)
                        item.CreatorName = user.ArFullName;
                }
            }
            return list;
        }
        private List<KafuRecord> FillRicipentName(List<KafuRecord> list)
        {
            if (list != null)
            {
                foreach (var item in list)
                {
                    item.RecName = KafuServices.GetEmployeeByNumber(item.RecipientId).ArFullName;
                }
            }
            return list;
        }
    }
}
