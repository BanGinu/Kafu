﻿using Microsoft.AspNetCore.Mvc;
using Kafu.Model.Services;
using System.Diagnostics;
using Microsoft.AspNetCore.Localization;
using Kafu.Model.Resource;
using static Kafu.WebUI.Controllers.Enum;
using Kafu.Models;
using Kafu.Model.Helper;

namespace Kafu.WebUI.Controllers
{
    public class Enum
    {
        public enum NotificationType
        {
            error,
            success,
            warning,
            info
        }
    }
    public class BaseController : Controller
    {
        public readonly IKafuServices KafuServices;
        protected readonly LocService _localizationHelper;
        protected readonly string _domain;

        public BaseController(IKafuServices KafuServices, ILogger<HomeController> logger, LocService localizationHelper)
        {
            this.KafuServices = KafuServices;
            this._localizationHelper = localizationHelper;
            _domain = ConfigurationHelper.GetValue<string>("Domain");
        }

        public void Alert(string message, NotificationType notificationType)
        {
            var msg =
                " swal('"
                + notificationType.ToString().ToUpper()
                + "', '" + message + "','" + notificationType.ToString() + "');" + " ";

            TempData["notification"] = msg;
        }

        /// <summary>
        /// Sets the information for the system notification.
        /// </summary>
        /// <param name="message">The message to display to the user.</param>
        /// <param name="notifyType">The type of notification to display to the user: Success, Error or Warning.</param>
        public void Message(string message, NotificationType notifyType)
        {
            TempData["Notification2"] = message;

            switch (notifyType)
            {
                case NotificationType.success:
                    TempData["NotificationCSS"] = "alert-box success";
                    break;
                case NotificationType.error:
                    TempData["NotificationCSS"] = "alert-box errors";
                    break;
                case NotificationType.warning:
                    TempData["NotificationCSS"] = "alert-box warning";
                    break;

                case NotificationType.info:
                    TempData["NotificationCSS"] = "alert-box notice";
                    break;
            }
        }


        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
        [HttpPost]
        public IActionResult SetLanguage(string culture, string returnUrl, string returnUrlForLanguageSwitch)
        {
            Response.Cookies.Append(
                "KafuLang",
                CookieRequestCultureProvider.MakeCookieValue(new RequestCulture(culture)),
                new CookieOptions { Expires = DateTimeOffset.UtcNow.AddYears(1), Domain = _domain }
            );

            return Redirect(returnUrlForLanguageSwitch);
        }

    }


}