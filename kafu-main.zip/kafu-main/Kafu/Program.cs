using Kafu.Model.Helper;
using Kafu.Model.Resource;
using Kafu.Model.Services;
using Kafu.Model.ViewModel;
using Microsoft.AspNetCore.Localization;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.Extensions.Options;
using System.Globalization;

var builder = WebApplication.CreateBuilder(args);

builder.Services.Configure<EmailConfig>(builder.Configuration.GetSection("Email"));

builder.Services.AddLocalization(options => options.ResourcesPath = "Resource");
builder.Services.AddSingleton<LocService>();
builder.Services.Configure<RequestLocalizationOptions>(
                options =>
                {
                    var supportedCultures = new List<CultureInfo>
                    {
                        new CultureInfo("ar-SA")
                    };
                    options.DefaultRequestCulture = new RequestCulture(culture: "en-US", uiCulture: "ar-SA");
                    options.SupportedCultures = supportedCultures;
                    options.SupportedUICultures = supportedCultures;
                    options.RequestCultureProviders.Insert(0,
                        new CookieRequestCultureProvider { CookieName = "KafuLang" });
                });

builder.Services.AddDbContext<Kafu.Model.Kafu_SystemContext>(options =>
               options.UseSqlServer(
                   builder.Configuration.GetConnectionString("KafuConnection")));

builder.Services.AddScoped<IKafuServices, KafuServices>();

builder.Services.TryAddSingleton<IHttpContextAccessor, HttpContextAccessor>();

// Add services to the container.
builder.Services.AddControllersWithViews()
    .AddRazorRuntimeCompilation() /* RazorRuntimeCompilation for hot reload while under development  */
    .AddDataAnnotationsLocalization(localizationOptions =>
    {
        localizationOptions.DataAnnotationLocalizerProvider = (type, factory) => factory.Create(typeof(SharedResource));
    });

builder.Services.AddSingleton(builder.Configuration);

ConfigurationHelper.Initialize(builder.Configuration);

var app = builder.Build();

var locOptions = app.Services.GetService<IOptions<RequestLocalizationOptions>>();
app.UseRequestLocalization(locOptions.Value);


// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}


app.UseStaticFiles();

app.UseRouting();
app.UseCookiePolicy();


app.UseEndpoints(endpoints =>
{
    endpoints.MapControllerRoute(
        name: "default",
        pattern: "{controller=Home}/{action=Index}/{id?}"
    );

});


app.Run();
